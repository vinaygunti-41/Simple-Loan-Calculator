(() => {
'use strict';

/* ---------- Helpers ---------- */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
const ic = n => `<svg class="ic" aria-hidden="true"><use href="#i-${n}"/></svg>`;
const store = {
  get(k){ try { return JSON.parse(localStorage.getItem(k)); } catch(e){ return null; } },
  set(k,v){ try { localStorage.setItem(k, JSON.stringify(v)); } catch(e){} },
  del(k){ try { localStorage.removeItem(k); } catch(e){} }
};
const KEY = 'premium-loan-dash-v1', THEME_KEY = 'premium-loan-dash-theme';

const inr  = n => '₹' + Math.round(n).toLocaleString('en-IN');
const inr2 = n => n.toLocaleString('en-IN', {minimumFractionDigits:2, maximumFractionDigits:2});
const pct  = (n, d = 1) => (n * 100).toFixed(d) + '%';
const short = v => {
  const a = Math.abs(v);
  if (a >= 1e7) return '₹' + (+(v/1e7).toFixed(2)) + ' Cr';
  if (a >= 1e5) return '₹' + (+(v/1e5).toFixed(1)) + ' L';
  if (a >= 1e3) return '₹' + Math.round(v/1e3) + 'K';
  return '₹' + Math.round(v);
};
const num = el => { const v = parseFloat(String(el.value).replace(/,/g, '')); return isNaN(v) ? NaN : v; };
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const dur = (months) => { const y = Math.floor(months/12), m = months % 12; return [y ? y + (y === 1 ? ' yr' : ' yrs') : '', m ? m + (m === 1 ? ' mo' : ' mos') : ''].filter(Boolean).join(' ') || '0 mos'; };

const calcEmi = (P, annual, n) => {
  const r = annual / 1200;
  if (r === 0) return P / n;
  const f = Math.pow(1 + r, n);
  return P * r * f / (f - 1);
};
const annuity = (annual, n) => { // loan supported per ₹1 of EMI
  const r = annual / 1200;
  if (r === 0) return n;
  const f = Math.pow(1 + r, n);
  return (f - 1) / (r * f);
};
const schedule = (P, annual, n, emi) => {
  const r = annual / 1200, rows = []; let bal = P;
  for (let m = 1; m <= n; m++) {
    const i = bal * r;
    let p = emi - i;
    if (m === n || p > bal) p = bal;
    bal = Math.max(0, bal - p);
    rows.push({m, emi: p + i, principal: p, interest: i, bal});
  }
  return rows;
};

/* ---------- Elements ---------- */
const F = {amount:$('#amount'), rate:$('#rate'), years:$('#years'), fee:$('#fee'), down:$('#down')};
const amountRange = $('#amountRange');
const T = {altRate:$('#altRate'), altYears:$('#altYears'), altFee:$('#altFee'), extra:$('#extra'), sim:$('#simRate')};
const elapsedEl = $('#elapsed');
const analytics = $('#analytics');

let calc = null, elapsed = null;

/* ---------- Toast & tooltip ---------- */
let toastT;
function toast(msg){ const t = $('#toast'); t.textContent = msg; t.classList.add('on'); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('on'), 2800); }
const tip = $('#tip');
function showTip(html, pt){
  tip.innerHTML = html; tip.style.opacity = 1;
  const w = tip.offsetWidth, h = tip.offsetHeight;
  let x = pt.clientX + 14, y = pt.clientY - h - 10;
  if (x + w > innerWidth - 8) x = pt.clientX - w - 14;
  if (y < 8) y = pt.clientY + 18;
  tip.style.left = Math.max(8, x) + 'px'; tip.style.top = y + 'px';
}
const hideTip = () => { tip.style.opacity = 0; };
addEventListener('scroll', hideTip, {passive:true});

/* ---------- Ripple ---------- */
document.addEventListener('pointerdown', e => {
  const b = e.target.closest('.ripple'); if (!b || reduce) return;
  const r = b.getBoundingClientRect(), s = Math.max(r.width, r.height) * 2;
  const el = document.createElement('span'); el.className = 'rip';
  el.style.cssText = `width:${s}px;height:${s}px;left:${e.clientX - r.left - s/2}px;top:${e.clientY - r.top - s/2}px`;
  b.appendChild(el); setTimeout(() => el.remove(), 650);
});

/* ---------- Theme ---------- */
const root = document.documentElement;
const effTheme = () => root.dataset.theme || (matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark');
function paintThemeBtn(){
  const light = effTheme() === 'light';
  $('#themeBtn').innerHTML = ic(light ? 'moon' : 'sun') + `<span>${light ? 'Dark mode' : 'Light mode'}</span>`;
}
{ const saved = store.get(THEME_KEY); if (saved === 'light' || saved === 'dark') root.dataset.theme = saved; }
paintThemeBtn();
$('#themeBtn').addEventListener('click', () => {
  const next = effTheme() === 'light' ? 'dark' : 'light';
  root.dataset.theme = next; store.set(THEME_KEY, next); paintThemeBtn();
});
let prevTheme;
addEventListener('beforeprint', () => { prevTheme = root.dataset.theme; root.dataset.theme = 'light'; });
addEventListener('afterprint', () => { if (prevTheme) root.dataset.theme = prevTheme; else delete root.dataset.theme; });

/* ---------- Input behaviour ---------- */
function formatMoney(el){
  const pos = el.selectionStart ?? el.value.length;
  const before = el.value.slice(0, pos).replace(/\D/g, '').length;
  const digits = el.value.replace(/\D/g, '').slice(0, 11);
  const f = digits ? Number(digits).toLocaleString('en-IN') : '';
  el.value = f;
  let c = 0, i = 0;
  for (; i < f.length && c < before; i++) if (/\d/.test(f[i])) c++;
  try { el.setSelectionRange(i, i); } catch(e){}
}
function cleanDecimal(el){
  el.value = el.value.replace(/[^\d.]/g, '').replace(/(\..*)\./g, '$1').replace(/^(\d*\.\d{0,2}).*$/, '$1');
}
const moneyInputs = [F.amount, F.down, T.extra];
const decInputs = [F.rate, F.years, F.fee, T.altRate, T.altYears, T.altFee];
moneyInputs.forEach(el => el.addEventListener('input', () => formatMoney(el)));
decInputs.forEach(el => el.addEventListener('input', () => cleanDecimal(el)));

const setFill = r => r.style.setProperty('--fill', ((r.value - r.min) / (r.max - r.min) * 100) + '%');
[amountRange, elapsedEl, T.sim].forEach(setFill);
$('#monthSearch').addEventListener('input', e => { e.target.value = e.target.value.replace(/\D/g, ''); renderTable(); });

amountRange.addEventListener('input', () => {
  F.amount.value = Number(amountRange.value).toLocaleString('en-IN');
  setFill(amountRange); clearErr('amount'); live();
});
F.amount.addEventListener('input', () => {
  const v = num(F.amount); if (!isNaN(v)) { amountRange.value = clamp(v, +amountRange.min, +amountRange.max); setFill(amountRange); }
  clearErr('amount');
});
Object.keys(F).forEach(k => F[k].addEventListener('input', () => clearErr(k)));

function clearErr(k){ const p = $('#err-' + k); if (p) p.textContent = ''; F[k]?.closest('.field')?.classList.remove('invalid'); F[k]?.removeAttribute('aria-invalid'); }

let liveT;
function live(){ if (!calc) return; clearTimeout(liveT); liveT = setTimeout(() => calculate({anim:false, scroll:false}), 140); }

/* ---------- Validation ---------- */
function validate(show = true){
  const v = {
    amount: num(F.amount), rate: num(F.rate), years: num(F.years),
    fee: F.fee.value === '' ? 0 : num(F.fee),
    down: F.down.value === '' ? 0 : num(F.down)
  };
  const e = {};
  if (!(v.amount >= 10000)) e.amount = 'Enter a loan amount of at least ₹10,000.';
  if (!(v.rate >= 0.1 && v.rate <= 40)) e.rate = 'Enter an interest rate between 0.1% and 40%.';
  if (!(v.years >= 1 && v.years <= 40)) e.years = 'Enter a duration between 1 and 40 years.';
  if (isNaN(v.fee) || v.fee < 0 || v.fee > 10) e.fee = 'Enter a processing fee between 0% and 10%.';
  if (isNaN(v.down) || v.down < 0) e.down = 'Down payment cannot be negative.';
  else if (!e.amount && v.down > v.amount - 10000) e.down = 'Down payment must leave at least ₹10,000 to finance.';
  if (show) {
    Object.keys(F).forEach(k => {
      const box = F[k].closest('.field'), msg = $('#err-' + k);
      msg.textContent = e[k] || ''; box.classList.toggle('invalid', !!e[k]);
      if (e[k]) F[k].setAttribute('aria-invalid', 'true'); else F[k].removeAttribute('aria-invalid');
    });
    const first = Object.keys(e)[0]; if (first) F[first].focus();
  }
  return {ok: !Object.keys(e).length, v};
}

/* ---------- Summary cards ---------- */
const CARDS = [
  {id:'principal', label:'Principal Amount', icon:'wallet', tone:'cyan'},
  {id:'emi', label:'EMI Per Month', icon:'calendar', tone:'emerald'},
  {id:'interest', label:'Total Interest', icon:'trend', tone:'gold'},
  {id:'total', label:'Total Payment', icon:'card', tone:'blue'},
  {id:'ipct', label:'Interest Percentage', icon:'pie', tone:'violet'},
  {id:'fee', label:'Processing Fee', icon:'rupee', tone:'orange'}
];
$('#summary').innerHTML = CARDS.map((c, i) => `
  <article class="stat" style="--tone:var(--c-${c.tone});animation-delay:${.12 + i * .06}s">
    <div class="stat-top"><span class="chip">${ic(c.icon)}</span><span class="badge" id="bd-${c.id}">—</span></div>
    <div class="stat-label">${c.label}</div>
    <div class="stat-value num" id="sv-${c.id}">—</div>
  </article>`).join('');

function countTo(el, to, fmt, anim = true){
  cancelAnimationFrame(el._raf);
  if (!anim || reduce) { el.textContent = fmt(to); return; }
  const t0 = performance.now(), D = 950;
  const step = t => { const k = Math.min(1, (t - t0) / D); el.textContent = fmt(to * (1 - Math.pow(1 - k, 3))); if (k < 1) el._raf = requestAnimationFrame(step); };
  el._raf = requestAnimationFrame(step);
}

function renderSummary(anim){
  const {P, v, emi, interest, fee, total, n} = calc;
  const data = {
    principal: {val:P, fmt:inr, badge:pct(P / v.amount, 0) + ' financed'},
    emi: {val:emi, fmt:inr, badge:n + ' months'},
    interest: {val:interest, fmt:inr, badge:pct(interest / total) + ' of total'},
    total: {val:total, fmt:inr, badge:(total / P).toFixed(2) + '× principal'},
    ipct: {val:interest / P * 100, fmt:x => x.toFixed(1) + '%', badge:v.rate + '% p.a.'},
    fee: {val:fee, fmt:inr, badge:v.fee + '% of principal'}
  };
  CARDS.forEach(c => { const d = data[c.id]; countTo($('#sv-' + c.id), d.val, d.fmt, anim); $('#bd-' + c.id).textContent = d.badge; });
}

/* ---------- SVG chart builders ---------- */
function arcSVG(segs, R, sw, anim, extra = ''){
  const C = 2 * Math.PI * R; let cum = 0;
  const circles = segs.map(s => {
    const len = C * s.f, off = -cum * C; cum += s.f;
    const target = `${len} ${C - len}`;
    return `<circle class="arc" cx="100" cy="100" r="${R}" fill="none" style="stroke:${s.c}" stroke-width="${sw}" stroke-dasharray="${anim ? `0 ${C}` : target}" data-da="${target}" stroke-dashoffset="${off}" transform="rotate(-90 100 100)"/>`;
  }).join('');
  return `<svg viewBox="0 0 200 200" role="img" aria-label="Chart">${circles}${extra}</svg>`;
}
function kickArcs(box){
  const arcs = $$('[data-da]', box);
  if (reduce) return arcs.forEach(c => { c.style.strokeDasharray = c.dataset.da; });
  requestAnimationFrame(() => requestAnimationFrame(() => arcs.forEach(c => { c.style.strokeDasharray = c.dataset.da; })));
}
const legend = items => items.map(i => `<li><i style="background:${i.c}"></i><span>${i.l}</span><b>${i.v}</b><em>${i.p}</em></li>`).join('');

function renderDonutPie(anim){
  const {P, interest, fee, total, totalRepay, emi} = calc;
  const top = `<text class="dn-top" x="100" y="98">${inr(emi)}</text><text class="dn-sub" x="100" y="117">per month</text>`;
  $('#donut').innerHTML = arcSVG([{f:P / totalRepay, c:'var(--c-cyan)'}, {f:interest / totalRepay, c:'var(--c-gold)'}], 72, 22, anim, top);
  $('#donutLegend').innerHTML = legend([
    {c:'var(--c-cyan)', l:'Principal', v:inr(P), p:pct(P / totalRepay) + ' of repayments'},
    {c:'var(--c-gold)', l:'Interest', v:inr(interest), p:pct(interest / totalRepay) + ' of repayments'}
  ]);
  $('#pie').innerHTML = arcSVG([{f:P / total, c:'var(--c-cyan)'}, {f:interest / total, c:'var(--c-gold)'}, {f:fee / total, c:'var(--c-orange)'}], 45, 90, anim);
  $('#pieLegend').innerHTML = legend([
    {c:'var(--c-cyan)', l:'Principal', v:inr(P), p:pct(P / total) + ' of total payment'},
    {c:'var(--c-gold)', l:'Interest', v:inr(interest), p:pct(interest / total) + ' of total payment'},
    {c:'var(--c-orange)', l:'Processing fee', v:inr(fee), p:pct(fee / total) + ' of total payment'}
  ]);
  kickArcs($('#donut')); kickArcs($('#pie'));
}

function renderLine(anim){
  const {sched, P, n} = calc;
  const W = 620, H = 300, L = 62, Rm = 16, Tt = 14, B = 34, iw = W - L - Rm, ih = H - Tt - B;
  const x = m => L + iw * m / n, y = b => Tt + ih * (1 - b / P);
  const pts = [[0, P], ...sched.map(r => [r.m, r.bal])];
  const d = 'M' + pts.map(p => x(p[0]).toFixed(1) + ' ' + y(p[1]).toFixed(1)).join('L');
  const area = d + `L${x(n).toFixed(1)} ${Tt + ih}L${x(0)} ${Tt + ih}Z`;
  let grid = '';
  for (let i = 0; i <= 4; i++) { const v = P * i / 4, yy = y(v); grid += `<line class="grid-line" x1="${L}" x2="${W - Rm}" y1="${yy}" y2="${yy}"/><text class="ax" x="${L - 8}" y="${yy + 3.5}" text-anchor="end">${short(v)}</text>`; }
  const yrs = n / 12, step = Math.max(1, Math.ceil(yrs / 6)); let xt = '';
  for (let k = 0; k * step * 12 <= n; k++) { const m = k * step * 12; xt += `<text class="ax" x="${x(m)}" y="${H - 10}" text-anchor="${k === 0 ? 'start' : 'middle'}">${k === 0 ? 'Start' : 'Yr ' + k * step}</text>`; }
  $('#line').innerHTML = `<svg viewBox="0 0 ${W} ${H}" class="${anim ? 'anim' : ''}" role="img" aria-label="Outstanding balance over time">
    <defs><linearGradient id="lg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" style="stop-color:var(--c-cyan);stop-opacity:.4"/><stop offset="1" style="stop-color:var(--c-cyan);stop-opacity:0"/></linearGradient>
    <linearGradient id="ls" x1="0" y1="0" x2="1" y2="0"><stop offset="0" style="stop-color:var(--c-cyan)"/><stop offset="1" style="stop-color:var(--c-emerald)"/></linearGradient></defs>
    ${grid}${xt}<path class="lnarea" d="${area}" fill="url(#lg)"/><path class="lnpath" pathLength="1" d="${d}" stroke="url(#ls)"/>
    <g class="xh"><line y1="${Tt}" y2="${Tt + ih}" style="stroke:var(--muted)" stroke-dasharray="3 3"/><circle r="5" style="fill:var(--c-emerald);stroke:#fff" stroke-width="2"/></g></svg>`;
  const svg = $('#line svg'), xh = $('.xh', svg), ln = $('line', xh), dot = $('circle', xh);
  svg.addEventListener('pointermove', ev => {
    const rc = svg.getBoundingClientRect(), sx = (ev.clientX - rc.left) / rc.width * W;
    const m = clamp(Math.round((sx - L) / iw * n), 0, n), bal = m === 0 ? P : sched[m - 1].bal;
    const cx = x(m); ln.setAttribute('x1', cx); ln.setAttribute('x2', cx); dot.setAttribute('cx', cx); dot.setAttribute('cy', y(bal));
    xh.style.opacity = 1;
    showTip(`<b>${m === 0 ? 'Loan start' : 'Month ' + m + ' (year ' + Math.ceil(m / 12) + ')'}</b><br>Balance: ${inr(bal)}`, ev);
  });
  svg.addEventListener('pointerleave', () => { xh.style.opacity = 0; hideTip(); });
}

function renderBars(anim){
  const {sched} = calc, yrs = [];
  sched.forEach(r => { const i = Math.ceil(r.m / 12) - 1; (yrs[i] = yrs[i] || {y:i + 1, p:0, i:0, bal:0}); yrs[i].p += r.principal; yrs[i].i += r.interest; yrs[i].bal = r.bal; });
  const W = 620, H = 300, L = 62, Rm = 16, Tt = 14, B = 34, iw = W - L - Rm, ih = H - Tt - B;
  const max = Math.max(...yrs.map(o => Math.max(o.p, o.i))) * 1.08, gw = iw / yrs.length, bw = Math.min(18, gw * .36);
  const y = v => Tt + ih * (1 - v / max);
  let grid = '';
  for (let i = 0; i <= 4; i++) { const v = max * i / 4, yy = y(v); grid += `<line class="grid-line" x1="${L}" x2="${W - Rm}" y1="${yy}" y2="${yy}"/><text class="ax" x="${L - 8}" y="${yy + 3.5}" text-anchor="end">${short(v)}</text>`; }
  const step = Math.ceil(yrs.length / 10);
  const bars = yrs.map((o, i) => {
    const cx = L + gw * i + gw / 2, dl = Math.min(i * 30, 900);
    const lab = (i % step === 0 || i === yrs.length - 1) ? `<text class="ax" x="${cx}" y="${H - 10}" text-anchor="middle">${o.y}</text>` : '';
    return `<g class="bar-grp" data-i="${i}"><rect x="${cx - gw / 2}" y="${Tt}" width="${gw}" height="${ih}" fill="transparent"/>
      <rect class="bar" x="${cx - bw - 1}" y="${y(o.p)}" width="${bw}" height="${Tt + ih - y(o.p)}" rx="3" style="fill:var(--c-cyan);animation-delay:${dl}ms"/>
      <rect class="bar" x="${cx + 1}" y="${y(o.i)}" width="${bw}" height="${Tt + ih - y(o.i)}" rx="3" style="fill:var(--c-gold);animation-delay:${dl + 60}ms"/>${lab}</g>`;
  }).join('');
  $('#bars').innerHTML = `<svg viewBox="0 0 ${W} ${H}" class="${anim ? 'anim' : ''}" role="img" aria-label="Year-wise principal and interest">${grid}${bars}</svg>`;
  const svg = $('#bars svg');
  svg.addEventListener('pointermove', ev => {
    const g = ev.target.closest('[data-i]'); if (!g) return hideTip();
    const o = yrs[+g.dataset.i];
    showTip(`<b>Year ${o.y}</b><br>Principal: ${inr(o.p)}<br>Interest: ${inr(o.i)}<br>Closing balance: ${inr(o.bal)}`, ev);
  });
  svg.addEventListener('pointerleave', hideTip);
}

/* ---------- Progress rings ---------- */
const RC = 2 * Math.PI * 52;
[1, 2, 3].forEach(i => { const c = $('#rg' + i); c.style.strokeDasharray = RC; c.style.strokeDashoffset = RC; });
function setRing(i, p, anim){
  const c = $('#rg' + i), v = $('#rv' + i), to = RC * (1 - clamp(p, 0, 1));
  if (anim && !reduce) { c.style.transition = 'none'; c.style.strokeDashoffset = RC; c.getBoundingClientRect(); c.style.transition = ''; }
  requestAnimationFrame(() => { c.style.strokeDashoffset = to; });
  countTo(v, p * 100, x => Math.round(x) + '%', anim);
}
function elapsedStats(){
  const {sched, P, n, interest} = calc;
  const paidRows = sched.slice(0, elapsed);
  const prin = paidRows.reduce((s, r) => s + r.principal, 0), int = paidRows.reduce((s, r) => s + r.interest, 0);
  return {prin, int, bal: elapsed === 0 ? P : sched[elapsed - 1].bal, remainInt: interest - int};
}
function renderProgress(anim){
  const {n, totalRepay, interest, P} = calc;
  elapsedEl.max = n; elapsedEl.value = elapsed; setFill(elapsedEl);
  $('#elapsedLbl').textContent = elapsed + (elapsed === 1 ? ' month' : ' months') + (elapsed ? ' (' + dur(elapsed) + ')' : '');
  setRing(1, elapsed / n, anim); setRing(2, interest / totalRepay, anim); setRing(3, P / totalRepay, anim);
  const s = elapsedStats();
  $('#progNote').innerHTML = elapsed === 0 ? 'Move the slider to see how much of the principal you would have repaid.' :
    `After <b>${elapsed}</b> months you would have repaid <b>${inr(s.prin)}</b> of principal and paid <b>${inr(s.int)}</b> in interest, leaving a balance of <b>${inr(s.bal)}</b>.`;
  if (!anim) renderQuickSavings(false);
  $$('#schedBody tr.now').forEach(r => r.classList.remove('now'));
  if (elapsed) $('#schedBody tr[data-m="' + elapsed + '"]')?.classList.add('now');
}
elapsedEl.addEventListener('input', () => { if (!calc) return; elapsed = +elapsedEl.value; renderProgress(false); save(); });

/* ---------- Schedule table ---------- */
function renderTable(){
  if (!calc) return;
  const q = $('#monthSearch').value.trim();
  const rows = q ? calc.sched.filter(r => String(r.m).startsWith(q)) : calc.sched;
  $('#schedBody').innerHTML = rows.length ? rows.map(r =>
    `<tr data-m="${r.m}"${r.m === elapsed ? ' class="now"' : ''}><td>${r.m}</td><td>${inr2(r.emi)}</td><td>${inr2(r.principal)}</td><td>${inr2(r.interest)}</td><td>${inr2(r.bal)}</td></tr>`).join('')
    : `<tr><td class="empty" colspan="5">No month matches “${q}”. Enter a number from 1 to ${calc.n}.</td></tr>`;
}

/* ---------- Quick insights ---------- */
const QUICK = [
  {id:'dur', label:'Loan Duration', icon:'calendar'},
  {id:'months', label:'Total Months', icon:'clock'},
  {id:'eff', label:'Effective Interest Paid', icon:'percent'},
  {id:'avgi', label:'Average Monthly Interest', icon:'trend'},
  {id:'avgp', label:'Average Monthly Principal', icon:'wallet'},
  {id:'save', label:'Total Savings if Prepaid', icon:'trend-down'}
];
$('#quick').innerHTML = QUICK.map(q => `<article class="card q"><div class="l">${ic(q.icon)}${q.label}</div><div class="v" id="qv-${q.id}">—</div><div class="s" id="qs-${q.id}"></div></article>`).join('');
function renderQuick(anim){
  const {n, v, interest, fee, P} = calc;
  countTo($('#qv-dur'), n / 12, x => (+x.toFixed(1)) + (n / 12 === 1 ? ' year' : ' years'), anim); $('#qs-dur').textContent = dur(n);
  countTo($('#qv-months'), n, x => Math.round(x) + ' months', anim); $('#qs-months').textContent = 'one EMI every month';
  countTo($('#qv-eff'), interest + fee, inr, anim); $('#qs-eff').textContent = pct((interest + fee) / P) + ' of principal, fee included';
  countTo($('#qv-avgi'), interest / n, inr, anim); $('#qs-avgi').textContent = 'averaged across all ' + n + ' months';
  countTo($('#qv-avgp'), P / n, inr, anim); $('#qs-avgp').textContent = 'principal repaid each month on average';
  renderQuickSavings(anim);
}
function renderQuickSavings(anim){
  if (!calc) return;
  const s = elapsedStats();
  countTo($('#qv-save'), s.remainInt, inr, anim);
  $('#qs-save').textContent = elapsed ? `interest avoided by closing after month ${elapsed}` : 'interest avoided if you repaid on day one';
}

/* ---------- Tools ---------- */
function renderCompare(){
  const {P, n, emi, interest, fee, v} = calc;
  const aR = num(T.altRate), aY = num(T.altYears), aF = T.altFee.value === '' ? 0 : num(T.altFee);
  const ok = aR >= 0.1 && aR <= 40 && aY >= 1 && aY <= 40 && aF >= 0 && aF <= 10;
  if (!ok) { $('#cmpBody').innerHTML = ''; $('#cmpEmi').textContent = '—'; $('#cmpInt').textContent = '—'; $('#cmpNote').textContent = 'Enter a rate (0.1–40%), a duration (1–40 years) and a fee (0–10%) for the alternative loan.'; return; }
  const aN = Math.round(aY * 12), aE = calcEmi(P, aR, aN), aI = aE * aN - P, aFee = P * aF / 100;
  $('#cmpBody').innerHTML = [
    ['EMI', inr(emi), inr(aE)], ['Interest', inr(interest), inr(aI)], ['Fee', inr(fee), inr(aFee)], ['Total cost', inr(P + interest + fee), inr(P + aI + aFee)]
  ].map(r => `<tr><td>${r[0]}</td><td>${r[1]}</td><td>${r[2]}</td></tr>`).join('');
  const dE = emi - aE, dI = interest - aI, net = (interest + fee) - (aI + aFee);
  const e = $('#cmpEmi'), i = $('#cmpInt');
  e.textContent = (dE >= 0 ? '−' : '+') + inr(Math.abs(dE)) + '/mo'; e.className = dE >= 0 ? 'pos' : 'neg';
  i.textContent = (dI >= 0 ? '' : '−') + inr(Math.abs(dI)); i.className = dI >= 0 ? 'pos' : 'neg';
  $('#cmpNote').textContent = net >= 0 ? `The alternative saves ${inr(net)} overall once fees are included.` : `The alternative costs ${inr(-net)} more overall once fees are included.`;
}
function simulatePrepay(P, annual, emi, extra){
  const r = annual / 1200; let bal = P, m = 0, intr = 0;
  while (bal > 0.5 && m < 1200) { const i = bal * r; intr += i; let p = emi + extra - i; if (p > bal) p = bal; if (p <= 0) break; bal -= p; m++; }
  return {months:m, interest:intr};
}
function renderPrepay(){
  const {P, n, emi, interest, v} = calc, extra = T.extra.value === '' ? 0 : num(T.extra);
  if (isNaN(extra) || extra < 0) return;
  const s = simulatePrepay(P, v.rate, emi, extra), saved = Math.max(0, n - s.months), iSaved = Math.max(0, interest - s.interest);
  $('#ppEmi').textContent = inr(emi + extra);
  $('#ppMonths').textContent = saved + (saved === 1 ? ' month' : ' months');
  $('#ppInt').textContent = inr(iSaved); $('#ppInt').className = iSaved > 0 ? 'pos' : '';
  $('#ppNote').textContent = extra === 0 ? 'Enter an extra monthly amount to see how much sooner you would be debt-free.' : `You would finish in ${dur(s.months)} instead of ${dur(n)}.`;
}
function renderSim(){
  const {P, n, fee, v, emi, total} = calc, r = +T.sim.value;
  setFill(T.sim); $('#simLbl').textContent = r.toFixed(1) + '%';
  const e = calcEmi(P, r, n), i = e * n - P, t = e * n + fee;
  $('#simEmi').textContent = inr(e); $('#simInt').textContent = inr(i); $('#simTot').textContent = inr(t);
  const d = t - total;
  $('#simNote').textContent = Math.abs(r - v.rate) < 0.05 ? 'This matches the rate you entered.' : `Compared with your ${v.rate}% rate, total payment ${d > 0 ? 'rises' : 'falls'} by ${inr(Math.abs(d))}.`;
}
[T.altRate, T.altYears, T.altFee].forEach(el => el.addEventListener('input', () => { if (calc) { renderCompare(); save(); } }));
T.extra.addEventListener('input', () => { if (calc) { renderPrepay(); save(); } });
T.sim.addEventListener('input', () => { if (calc) renderSim(); });

/* ---------- Main calculate ---------- */
function calculate({anim = true, scroll = true, restore = false} = {}){
  const {ok, v} = validate(anim && !restore);
  if (!ok) return false;
  const P = v.amount - v.down, n = Math.round(v.years * 12), emi = calcEmi(P, v.rate, n), sched = schedule(P, v.rate, n, emi);
  const totalRepay = emi * n, interest = totalRepay - P, fee = P * v.fee / 100, total = totalRepay + fee;
  calc = {v, P, n, emi, sched, totalRepay, interest, fee, total};
  elapsed = elapsed == null ? Math.round(n / 4) : clamp(elapsed, 0, n);

  if (T.altRate.value === '') { T.altRate.value = Math.max(0.1, +(v.rate - 0.5).toFixed(2)); T.altYears.value = v.years; T.altFee.value = +(Math.max(0, v.fee - 0.5)).toFixed(2); }
  if (anim) T.sim.value = clamp(Math.round(v.rate * 10) / 10, 5, 20);

  $('#summaryHint').hidden = true;
  analytics.hidden = false;
  const a = anim;
  renderSummary(a); renderDonutPie(a); renderLine(a); renderBars(a);
  renderTable(); renderQuick(a); renderProgress(a);
  renderCompare(); renderPrepay(); renderSim();
  save();
  if (scroll) analytics.scrollIntoView({behavior: reduce ? 'auto' : 'smooth', block:'start'});
  return true;
}
$('#loanForm').addEventListener('submit', e => { e.preventDefault(); elapsed = null; calculate({anim:true, scroll:true}); });
Object.values(F).forEach(el => el.addEventListener('input', live));

/* ---------- Reset ---------- */
$('#resetBtn').addEventListener('click', () => {
  const app = $('#dash'); app.classList.add('resetting');
  setTimeout(() => {
    Object.values(F).forEach(el => { el.value = ''; }); Object.keys(F).forEach(clearErr);
    Object.values(T).forEach(el => { if (el.type !== 'range') el.value = ''; });
    amountRange.value = 2500000; setFill(amountRange); T.sim.value = 8.5; setFill(T.sim);
    $('#monthSearch').value = '';
    calc = null; elapsed = null; analytics.hidden = true; $('#summaryHint').hidden = false;
    CARDS.forEach(c => { $('#sv-' + c.id).textContent = '—'; $('#bd-' + c.id).textContent = '—'; });
    store.del(KEY); app.classList.remove('resetting'); F.amount.focus();
    toast('Calculator reset. Enter new loan details to begin.');
  }, 420);
});

/* ---------- Persistence ---------- */
let saveT;
function save(){
  clearTimeout(saveT);
  saveT = setTimeout(() => {
    const s = {calculated: !!calc, elapsed};
    Object.keys(F).forEach(k => s[k] = F[k].value);
    ['altRate', 'altYears', 'altFee', 'extra'].forEach(k => s[k] = T[k].value);
    s.sim = T.sim.value; store.set(KEY, s);
  }, 250);
}

/* ---------- Exports ---------- */
async function saveFile(name, data, mime){
  try {
    const d = window.claude && claude.use ? await claude.use('downloads') : null;
    if (d) { await d.save({filename:name, data}); toast('Saved ' + name); return; }
  } catch (err) { if (err && err.code === 'declined') return toast('Download cancelled.'); }
  try {
    const url = URL.createObjectURL(data instanceof Blob ? data : new Blob([data], {type:mime}));
    const a = document.createElement('a'); a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500); toast('Download started: ' + name);
  } catch (e) { toast('Downloads are not available in this view.'); }
}
const needCalc = () => { if (calc) return true; toast('Calculate your EMI first.'); return false; };

$('#csvBtn').addEventListener('click', () => {
  if (!needCalc()) return;
  const head = 'Month,EMI,Principal Paid,Interest Paid,Remaining Balance';
  const rows = calc.sched.map(r => [r.m, r.emi.toFixed(2), r.principal.toFixed(2), r.interest.toFixed(2), r.bal.toFixed(2)].join(','));
  saveFile('loan-payment-schedule.csv', [head, ...rows].join('\n'), 'text/csv');
});

$('#pdfBtn').addEventListener('click', async () => {
  if (!needCalc()) return;
  if (!window.jspdf) { toast('The PDF library did not load. Try Print, then Save as PDF.'); return; }
  const {jsPDF} = window.jspdf, doc = new jsPDF({unit:'pt', format:'a4'}), W = doc.internal.pageSize.getWidth();
  const rs = n => 'Rs. ' + Math.round(n).toLocaleString('en-IN');
  const {v, P, n, emi, interest, fee, total, sched} = calc;
  doc.setFillColor(7, 28, 61); doc.rect(0, 0, W, 92, 'F');
  doc.setTextColor(255); doc.setFont('helvetica', 'bold'); doc.setFontSize(21); doc.text('Loan Calculator Report', 40, 52);
  doc.setFont('helvetica', 'normal'); doc.setFontSize(10);
  doc.text('Generated on ' + new Date().toLocaleDateString('en-IN', {day:'numeric', month:'long', year:'numeric'}), 40, 72);
  let y = 126; doc.setTextColor(20);
  const head = t => { doc.setFont('helvetica', 'bold'); doc.setFontSize(13); doc.setTextColor(15, 76, 129); doc.text(t, 40, y); y += 8; doc.setDrawColor(0, 180, 200); doc.line(40, y, W - 40, y); y += 20; doc.setTextColor(20); doc.setFontSize(11); };
  const line = (k, val) => { doc.setFont('helvetica', 'normal'); doc.text(k, 40, y); doc.setFont('helvetica', 'bold'); doc.text(val, W - 40, y, {align:'right'}); y += 19; };
  head('Loan inputs');
  line('Loan amount', rs(v.amount)); line('Down payment', rs(v.down)); line('Financed principal', rs(P));
  line('Interest rate', v.rate + '% per year'); line('Duration', dur(n)); line('Processing fee', v.fee + '%');
  y += 10; head('Results');
  line('EMI per month', rs(emi)); line('Total interest', rs(interest)); line('Processing fee', rs(fee)); line('Total payment', rs(total));
  line('Interest as % of principal', (interest / P * 100).toFixed(1) + '%');
  y += 10; head('Year-wise breakdown');
  const cols = [40, 250, 380, W - 40];
  const row = (a, b, c, d, bold) => { doc.setFont('helvetica', bold ? 'bold' : 'normal'); doc.setFontSize(10); doc.text(a, cols[0], y); doc.text(b, cols[1], y, {align:'right'}); doc.text(c, cols[2], y, {align:'right'}); doc.text(d, cols[3], y, {align:'right'}); y += 16; };
  row('Year', 'Principal paid', 'Interest paid', 'Closing balance', true);
  const yrs = []; sched.forEach(r => { const i = Math.ceil(r.m / 12) - 1; (yrs[i] = yrs[i] || {p:0, i:0, b:0}); yrs[i].p += r.principal; yrs[i].i += r.interest; yrs[i].b = r.bal; });
  yrs.forEach((o, i) => { if (y > 790) { doc.addPage(); y = 60; } row(String(i + 1), rs(o.p), rs(o.i), rs(o.b)); });
  y += 14; if (y > 800) { doc.addPage(); y = 60; }
  doc.setFont('helvetica', 'italic'); doc.setFontSize(8.5); doc.setTextColor(110);
  doc.text('Estimates for planning purposes only. This is not a bank offer.', 40, y);
  saveFile('loan-report.pdf', doc.output('blob'), 'application/pdf');
});

$('#printBtn').addEventListener('click', () => {
  if (!needCalc()) return;
  try { window.print(); } catch (e) { toast('Printing is not available here. Use PDF report instead.'); }
});

$('#shareBtn').addEventListener('click', async () => {
  if (!needCalc()) return;
  const {v, P, n, emi, interest, total} = calc;
  const text = `Loan summary: ${inr(P)} at ${v.rate}% for ${dur(n)}. EMI ${inr(emi)} per month, total interest ${inr(interest)}, total payment ${inr(total)}.`;
  try { if (navigator.share) { await navigator.share({title:'Loan summary', text}); return; } } catch (e) { if (e && e.name === 'AbortError') return; }
  try { await navigator.clipboard.writeText(text); toast('Summary copied to clipboard.'); return; } catch (e) {}
  try { const ta = document.createElement('textarea'); ta.value = text; ta.style.cssText = 'position:fixed;opacity:0'; document.body.appendChild(ta); ta.select(); document.execCommand('copy'); ta.remove(); toast('Summary copied to clipboard.'); }
  catch (e) { toast('Sharing is not available here.'); }
});

/* ---------- Restore last calculation ---------- */
(function restore(){
  const s = store.get(KEY); if (!s) return;
  try {
    Object.keys(F).forEach(k => { if (typeof s[k] === 'string') F[k].value = s[k]; });
    ['altRate', 'altYears', 'altFee', 'extra'].forEach(k => { if (typeof s[k] === 'string') T[k].value = s[k]; });
    const a = num(F.amount); if (!isNaN(a)) { amountRange.value = clamp(a, +amountRange.min, +amountRange.max); setFill(amountRange); }
    if (s.sim) { T.sim.value = s.sim; }
    if (s.calculated) { elapsed = typeof s.elapsed === 'number' ? s.elapsed : null; calculate({anim:true, scroll:false, restore:true}); if (s.sim) { T.sim.value = s.sim; renderSim(); } }
  } catch (e) {}
})();
})();
